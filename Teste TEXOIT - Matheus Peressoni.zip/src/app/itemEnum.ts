export enum UnidadeMedida {
    Litro = "LT",
    Quilograma = "KG",
    Unidade = "UM",
}