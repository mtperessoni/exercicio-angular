﻿Para rodar o projeto, é necessário que possua o Node e o Angular CLI instalado .
É possível instalar o Angular CLI através do comando: npm install -g @angular/cli

Caso você já possua instalado, é necessário abrir um terminal(cmd) e acessar a pasta.
Exemplo: cd C:\Projetos\texoit

Após entrar na pasta, rodar o comando npm install para que seja baixado as dependencias do projeto.
Depois de baixado as dependências, basta rodar o comando "ng serve" para subir. é possível acessar atrvés da URL "http://localhost:4200/".
Para rodar os testes unitários, é necessário executar o comando "ng test".
